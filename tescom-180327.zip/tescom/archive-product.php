<?php
get_header();
$description = get_field("des");
$dimensions = get_field("dim");
$performance = get_field("per");
$options = get_field("customization_options");
$data = get_field("download_data_sheet");
$imgRear = get_field("rear_view_Image");
$imageSide = get_field("side_view_Image");
$main_column_size = bootstrapBasicGetMainColumnSize();
?>

<div class="row">
  <div class="col-md-12">
    <h1 class="entry-title text-left">
      <?php the_title(); ?>
    </h1>
  </div>
</div>
<!-- end row-->
<div class="row">
  <div class="col-xs-4 portfolio-item text-center"> <a href="#">
    <?php the_post_thumbnail('full', array('class' => 'img-responsive')); ?>
    </a>
    <div class="imgDesc">Font View</div>
  </div>
  <div class="col-xs-4 portfolio-item text-center"> <a href="#">
    <?php    if( !empty($imageSide) ):  ?>
    <img src="<?php echo $imageSide ?>" class="img-responsive" alt="<?php wp_title(); ?>" />
    <?php endif; ?>
    </a>
   <div class="imgDesc">Rear View</div>
  </div>
  <div class="col-xs-4 portfolio-item text-center"> <a href="#">
    <?php    if( !empty($imgRear) ): ?>
    <img src="<?php echo $imgRear ?>" class="img-responsive" alt="<?php wp_title(); ?>" />
    <?php endif; ?>
    </a>
    <div class="imgDesc">Side View</div>
  </div>
</div>
<!-- end row-->
<div class="row">
  <div class="col-md-6">
    <h2>Description:</h2>
    <p>Provides RF radiation shielding for testing medium to large size wireless engineering, manufacturing and service devices.</p>
  </div>
  <div class="col-md-6">
    <h2>Performance:</h2>
    <p> > 60 dB at 900MHz
      > 60 dB at 1.8GHz
      > 60 dB at 2.4GHz
      > 55 dB at 5.8GHz</p>
  </div>
</div>
<!-- end row-->
<div class="row">
  <div class="col-md-6">
    <h2>Dimensions:</h2>
    <p>Provides RF radiation shielding for testing medium to large size wireless engineering, manufacturing and service devices.</p>
  </div>
  <div class="col-md-6">
    <h2>Customization Options:</h2>
    <p> Inner Dimension (in mm):
      530(W)×540(D)×420(H), 195(D) top side
      Inner Dimension (in mm):
      530(W)×540(D)×420(H), 195(D) top side</p>
  </div>
</div>
<!-- end row-->

<?php get_footer(); ?>
