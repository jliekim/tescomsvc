 <?php /* Template Name: Page - Search Template */ ?>

<?php get_header(); ?>
<?php get_template_part('template-part', 'head'); ?>
<?php get_template_part('template-part', 'topnav'); ?>


<div class="container about">
  <div class="row faq">
    <div class="col-md-10 col-md-offset-1">
      <div class="row faq">
        <form class="form-horizontal bottomSearch hidden-xs" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
          <div class="form-group">
            <label class="control-label col-sm-2 col-md-2" for="s">Search</label>
            <div class="col-sm-10 inner-addon left-addon"> <i class="glyphicon glyphicon-search"></i>
              <input type="text" id="s" class="form-control" name="s" placeholder="" onblur="if (this.value == '')  
{this.value = '<?php echo $search_text; ?>';}"  
onfocus="if (this.value == '<?php echo $search_text; ?>')  
{this.value = '';}" /> 
            </div>
          </div>
          <input type="hidden" id="searchsubmit" /> 
        </form>
      </div>

    </div>
  </div>
</div>
<!-- end content container -->
</div>

<?php get_footer(); ?>
