<?php get_header(); ?>
<?php get_template_part('template-part', 'head'); ?>
<?php get_template_part('template-part', 'topnav'); ?>

<div class="container contentContainer" style="padding-bottom: 80px;">
  <h1 style="text-align: left; text-transform: UPPERCASE; padding: 80px 0px 0px 0px; color: #333333;">
    <?php printf( __( '<span>Search Results for: <strong>%s</strong></span>'), '<span>' . get_search_query() . '</span>' );
    // printf( __( '<span><strong>Search</strong> Results</span>', 'shape' )); 
    ?>
  </h1>
  <br/>
  <br/>
  <?php if ( have_posts() ) : ?>
     <?php /* Start the Loop */ ?>
      <?php while ( have_posts() ) : the_post(); ?>
        <h4> <? the_title(); ?></h4>
         <? the_excerpt(); ?>
         <p><a href="<? the_permalink(); ?>">Read more &raquo;</a></p>
         <hr />
      <?php endwhile; ?>
      <?php else : ?>
      Your search term  <strong>"<? echo get_search_query();  ?>"</strong> did not return any results.  
  <?php endif; ?>
</div>

<?php get_footer(); ?>
