<?php /* Template Name: Page - TEM Cells Template */ ?>

<?php get_header(); ?>

<?php get_template_part('template-part', 'head'); ?>

<?php get_template_part('template-part', 'topnav'); ?>

<div class="container contentContainer">
  <?php // theloop
  if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
  <h1 class="page-header"><?php the_title() ;?></h1>
  <?php the_content(); ?>
  <?php endwhile; ?>
  <?php else: ?>
    <?php get_404_template(); ?>
  <?php endif; ?>
</div>
<div class="productTableContainer">
  <div class="container">
    <h2 class="productTableTitle"> ALL TEM CELLS</h2>
    <div class="table-responsive-md">
      <table class="table">
        <thead>
          <th scope="col" class="productTableHeader"><h3>Product Name</h3></th>
          <th scope="col" class="productTableHeader"><h3>Operation</h3></th>
          <th scope="col" class="productTableHeader"><h3>Application</h3></th>
          <th scope="col" class="productTableHeader"><h3>Dimension (Inner, Outer)</h3></th>
          <th scope="col" class="productTableHeader"><h3>Weight</h3></th>
          <th scope="col" class="productTableHeader"><h3>Typical RF Shielding</h3></th>
        </thead>
        <tbody>
        <?php
            $query = new AirpressQuery();
            $query->setConfig("Product Catalog");
            $query->table("Product Catalog");
            $query->addFilter("{Type}='TEM Cells'");
            $events = new AirpressCollection($query);
          ?>
        <?php foreach($events as $e): ?>
          <tr class="table-active productTableRow">
            <td class="table-active productTableRow">
              <?php  $name = $e["Name"] ;?>
              <p><a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a></p>
              <?php $productImageUrl = $e["Product Image"][1]["url"] ;?>
              <?php if ($productImageUrl) { ;?>
                <a href="<?php  site_url(); ?>/<?php echo $name; ?>">
                  <img class="alignnone customProductImage size-thumbnail" src="<?php echo $productImageUrl ;?>" alt="Product Image" width="30px"/>
                </a>
            <? } ;?>
            </td>
            <td class="table-active productTableRow">
            <?php if ($operation) { ;?>
              <p><?php  echo $operation; ?></p>
            <? } ;?>
            </td>
             <td class="table-active productTableRow">
            <?php  $applications = $e["Application"]; ?>
            <?php if ($applications) { ;?>
              <?php foreach($applications as $a): ?>
                <p><?php echo $a;?></p>
              <?php endforeach; ?>
            <? } ;?>
            </td>
            <td class="table-active productTableRow">
            <?php $inner = $e["Inner Dimension (WxDxH)"]; ?>
            <?php if ($inner) { ;?>
              <p><?php  echo $inner; ?></p>
            <? } ;?>
            <?php $outer = $e["Outer Dimension (WxDxH)"]; ?>
            <?php if ($outer) { ;?>
              <p><?php  echo $outer; ?></p>
            <? } ;?>
            </td>
            <td class="table-active productTableRow">
            <?php  $weight = $e["Weight"] ;?>
            <?php if ($weight) { ;?>
              <p><?php  echo $weight ;?></p>
            <? } ;?>
            </td>
            <td class="table-active productTableRow">
            <?php  $shielding = $e["Shielding Effectiveness"] ;?>
            <?php if ($shielding) { ;?>
              <p><?php  echo $shielding ;?></p>
            <? } ;?>
            </td>
          </tr>
      <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php get_footer(); ?>
