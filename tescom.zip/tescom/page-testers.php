<?php
/*
 * Template Name: Custom tester page
 * Description: Page template without sidebar
 */
?>
<?php get_header(); ?>
<?php get_template_part('template-part', 'head'); ?>
<?php get_template_part('template-part', 'topnav'); 

$des = get_field("des");
$dim = get_field("dim");
$per = get_field("per");
$options = get_field("customization_options");
$data = get_field("download_data_sheet");
$imgRear = get_field("rear_view_Image");
$imageSide = get_field("side_view_Image");
?>

<!-- start content container -->

<div class="container">
  <div class="row">
    <div class="col-sm-12">
      <h1 class="entry-title">TESTERS</h1>
    </div>
  </div>
  <!--close row-->
  <br />
  <!--close row-->
  <div class="row">
    <?php  
$posts = get_posts(array(
	'posts_per_page'	=> -1,
	'post_type'			=> 'product',
	'meta_key'		=> 'type_of_shield',
	'meta_value'	=> 'testers'
));

if( $posts ): 
foreach( $posts as $post ): 
setup_postdata( $post );
  ?>
    <div class="col-lg-2 col-md-3 col-sm-4 col-xs-4 portfolio-item clearfix"> <a href="<? the_permalink();?>">
      <?php the_post_thumbnail('full', array('class' => 'img-responsive', 'width' => '160')); ?>
      </a>
     
      <h3> 
      <a href="<? the_permalink();?>" > <? the_title();?></a>
       </h3>
    </div>
    <?php endforeach; ?>
  </div>
  <!--ends row-->
  
  <?php wp_reset_postdata(); ?>
  <?php endif; ?>
  <!-- end manual shields --><br /><br /><br /><br /><br />
  <div class="row hidden-xs hidden-sm"> 
<div class="col-md-12 text-right return ">  
 return to entire <a href="/product-catalog/">product catalog</a><br /><br />
 </div>
 </div>
</div>
<?php get_footer(); ?>
