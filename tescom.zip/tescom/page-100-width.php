<?php
/*
 * Template Name: Custom Full Width
 * Description: Page template without sidebar
 */
?>

<?php get_header(); ?>

<?php get_template_part('template-part', 'head'); ?>

<?php get_template_part('template-part', 'topnav'); ?>
<!-- start content container -->

<div class="container">
  <div class="row faq">
    <div class="col-md-10 col-md-offset-1 col-lg-offset-1">
      <h1 class="page-header hidden-md hidden-lg entry-title">
        <?php the_title() ;?>
      </h1>
      <h1 class="page-header hidden-xs hidden-sm entry-title"> <?php the_title() ;?></h1>
    </div>
  </div>
 
 
  <div class="col-md-<?php devdmbootstrap3_main_content_width(); ?> faqcon dmbs-main col-md-offset-2 col-lg-offset-2">
    <?php // theloop
        if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <?php the_content(); ?>
    <?php endwhile; ?>
    <?php else: ?>
    <?php get_404_template(); ?>
    <?php endif; ?>
  </div>

<!-- end content container -->
</div>
<?php get_footer(); ?>
