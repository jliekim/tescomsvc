<!-- Hidden on XS screens -->
<div class="d-none d-sm-block">
  <nav class="navbar fixed-top navbar-expand-lg justify-content-center">
    <a class="navbar-brand d-flex mr-auto" href="<?=site_url()?>">
      <img src="<?=site_url()?>/wp-content/uploads/2017/01/tescomlogo-8-300x45.png" alt="Tescom Logo" />
    </a> 
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapseContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  <div class="collapse navbar-collapse text-center" id="navbarCollapseContent">
    <ul class="nav navbar-nav ml-auto w-100 justify-content-end">
      <li class="nav-item dropdown">
          <a class="navMenuHeaders nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Products
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <div class="dropdown-item">
                <div class="container productCatalogMenu">
                    <div class="col-sm-4 col-md-4">
                      <h2><a href="/shield-boxes">SHIELD BOXES</a></h2>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Shield Boxes'");
                            $query->addFilter("{Operation}='Pneumatic'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Pneumatic
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                          <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Shield Boxes'");
                            $query->addFilter("{Operation}='Manual'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Manual
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                    </div>
                    <div class="col-sm-4 col-md-4">
                      <h2><a href="/tem-cells">TEM CELLS</a></h2>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='TEM Cells'");
                            $query->addFilter("{Operation}='Pneumatic'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Pneumatic
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                          <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='TEM Cells'");
                            $query->addFilter("{Operation}='Manual'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Manual
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                    </div>
                    <div class="col-sm-4 col-md-4">
                      <h2><a href="/test-instruments">TEST INSTRUMENTS</a></h2>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Test Instruments'");
                            $query->addFilter("{Application}='DAB/DMB'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    DAB/DMB
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                          <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Test Instruments'");
                            $query->addFilter("{Application}='RFID'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    RFID
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/test-instruments/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Test Instruments'");
                            $query->addFilter("{Application}='GNSS'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    GNSS
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/test-instruments/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Test Instruments'");
                            $query->addFilter("{Application}='Bluetooth'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Bluetooth
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/test-instruments/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                    </div>
                </div>
              </div>
           </div>
          </li>
          <li class="nav-item"><a class="navMenuHeaders" href="<?=site_url()?>/customer-support">Customer Support</a></li>
          <li class="nav-item" ><a class="navMenuHeaders" href="<?=site_url()?>/contact-us">Contact Us</a></li>
          <?php if (is_user_logged_in() ) { ;?>
            <li class="nav-item dropdown">
                <a class="navMenuHeaders nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Logged In</a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <div class="dropdown-item">
                    <a class="navMenuHeaders" href="<?=site_url()?>/dashboard">Dashboard</a>
                  </div>
                  <div class="dropdown-item">
                    <a class="navMenuHeaders" href="<?=site_url()?>/settings">Settings</a>
                  </div>
                  <div class="dropdown-item">
                    <a class="navMenuHeaders" href="<?=site_url()?>/wp-login.php?action=logout&redirect_to=<?=site_url()?>">
               Logout</a>
                  </div>
                </div>
             </li>
          <?php } elseif (!is_user_logged_in() ) { ;?>
          <li class="nav-item" >
              <a class="navMenuHeaders" href="<?=site_url()?>/login">
                Login </a>
            </li >
          <?php };?>
          <li class="nav-item dropdown">
              <a class="navMenuHeaders nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Search</a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <div class="dropdown-item">
                  <form class="form-horizontal" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
                    <div class="form-group">
                      <input type="text" id="s" class="form-control mobileSearchInput" name="s" placeholder="Search" />  
                    </div>
                    <input type="hidden" id="searchsubmit" />
                  </form>
                </div>
              </div>
            </li>
      </ul>
    </div>
  </nav>
  <div class="navTagline justify-content-start">
    <p>TESCOM KOREA'S OFFICIAL US BRANCH</p>
  </div>
</div>

<!-- Visible only on XS screens -->
<div class="d-block d-sm-none">
  <nav class="navbar fixed-top ">
    <div class="row">
      <a class="navbar-brand" href="<?=site_url()?>">
        <img src="<?=site_url()?>/wp-content/uploads/2017/01/tescomlogo-8-300x45.png" width="125px" height="18.75px" alt="Tescom Logo"/>
      </a>
    </div>
    <ul class="nav">
      <li class="nav-item dropdown">
          <a class="navMenuHeaders nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Products
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <div class="dropdown-item">
                <div class="container">
                    <div class="col-sm-4 col-md-4">
                      <h2><a href="/shield-boxes">SHIELD BOXES</a></h2>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Shield Boxes'");
                            $query->addFilter("{Operation}='Pneumatic'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Pneumatic
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                          <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Shield Boxes'");
                            $query->addFilter("{Operation}='Manual'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Manual
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                    </div>
                    <div class="col-sm-4 col-md-4">
                      <h2><a href="/tem-cells">TEM CELLS</a></h2>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='TEM Cells'");
                            $query->addFilter("{Operation}='Pneumatic'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Pneumatic
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                          <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='TEM Cells'");
                            $query->addFilter("{Operation}='Manual'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Manual
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                    </div>
                    <div class="col-sm-4 col-md-4">
                      <h2><a href="/test-instruments">TEST INSTRUMENTS</a></h2>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Test Instruments'");
                            $query->addFilter("{Application}='DAB/DMB'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    DAB/DMB
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                          <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Test Instruments'");
                            $query->addFilter("{Application}='RFID'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    RFID
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/test-instruments/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Test Instruments'");
                            $query->addFilter("{Application}='GNSS'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    GNSS
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/test-instruments/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                        <?php
                            $query = new AirpressQuery();
                            $query->setConfig("Product Catalog");
                            $query->table("Product Catalog");
                            $query->addFilter("{Type}='Test Instruments'");
                            $query->addFilter("{Application}='Bluetooth'");
                            $events = new AirpressCollection($query);
                          ?>
                          <?php foreach($events as $e): ?>
                              <div align="left" class="row">
                                  <div class="col-md-6">
                                    Bluetooth
                                  </div>
                                  <div class="col-md-6">
                                    <?php  $name = $e["Name"] ;?>
                                    <a href="<?php  site_url(); ?>/test-instruments/<?php echo $name; ?>"><?php echo $name; ?></a>
                                  </div>
                              </div>
                          <?php endforeach; ?>
                    </div>
                </div>
              </div>
           </div>
        </li>
        <li class="nav-item dropdown">
          <a class="navMenuHeaders nav-link dropdown-toggle" href="#" id="navbarDropdown" data-toggle="dropdown" ole="button" aria-haspopup="true" aria-expanded="false">
            More
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <div class="dropdown-item" id="mobileMenuForMore">
              <a class="navMenuHeaders nav-item" href="<?=site_url()?>/contact-us">Contact Us</a>
            </div>
            <div class="dropdown-item" id="mobileMenuForMore">
              <a class="navMenuHeaders nav-item" href="<?=site_url()?>/customer-support">
                Customer Support
              </a>
            </div>
            <?php if (is_user_logged_in() ) { ;?>
              <div class="dropdown-item" id="mobileMenuForMore">
                <a class="navMenuHeaders" href="<?=site_url()?>/dashboard">Dashboard</a>
              </div>
              <div class="dropdown-item" id="mobileMenuForMore">
                <a class="navMenuHeaders" href="<?=site_url()?>/settings">Settings</a>
              </div>
              <div class="dropdown-item" id="mobileMenuForMore">
                <a class="navMenuHeaders" href="<?=site_url()?>/wp-login.php?action=logout&redirect_to=<?=site_url()?>">
                     Logout</a>
              </div>
            <?php } elseif (!is_user_logged_in() ) { ;?>
              <div class="dropdown-item" id="mobileMenuForMore">
                   <a class="navMenuHeaders nav-item" href="<?=site_url()?>/login">
                       Login
                   </a>
              </div>
            <?php };?>
            <div class="dropdown-item" id="mobileMenuForMore">
              <form class="form-inline" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
                <div class="form-group">
                  <input type="text" id="s" class="searchMenuOnMobile form-control mr-sm-2" aria-label="Search" name="s" placeholder="Search">
                </div>
                <input type="hidden" id="searchsubmit" />
              </form>
             </div>
          </div>
       </li>
     </ul>
  </nav>
  <div class="navTagline justify-content-start">
    <p>TESCOM KOREA'S OFFICIAL US BRANCH</p>
  </div>
</div>
