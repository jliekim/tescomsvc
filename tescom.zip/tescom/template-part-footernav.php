<!-- <?php //if ( has_nav_menu( 'footer_menu' ) ) : ?> -->

<div class="footerMenu">
  <div class="footerContainer container">
  <br/>
  <br/>
  <br/>
  <br/>
  <div class="row">
    <div class="col-md-3 col-lg-3">
      <h3>PRODUCT CATALOG</h3> 	
      <p><a href="<?=site_url()?>/shield-boxes/">Shield Boxes</a></p>
      <p><a href="<?=site_url()?>/tem-cells/">TEM Cells</a></p>
      <p><a href="<?=site_url()?>/test-instruments/">Test Instruments</a></p>
    </div>
    <div class="col-md-3 col-lg-3">
      <h3>CUSTOMER SUPPORT</h3> 	
      <p><a href="<?=site_url()?>/customer-support#how-to-order">How to Order</a></p>
      <p><a href="<?=site_url()?>/customer-support#shipping-and-handling">Shipping & Handling</a></p>
      <p><a href="<?=site_url()?>/customer-support#returns-and-refunds">Returns & Refunds</a></p>
      <p><a href="<?=site_url()?>/customer-support#repairs">Repairs</a></p>
    </div>
    <div class="col-md-3 col-lg-3">
      <h3>COMPANY</h3> 	
      <p><a href="<?=site_url()?>/company#our-company/">Our Company</a></p>
      <p><a href="<?=site_url()?>/contact-us/">Contact Us</a></p>
    </div>
    <div class="col-md-3 col-lg-3">
      <h3>EXISTING CUSTOMERS</h3> 	
      <p><a href="<?=site_url()?>/login/">Login</a></p>
      <p><a href="<?=site_url()?>/register/">Register</a></p>
    </div>
  </div> <!-- row --> 
  <br/>
  <div class="row">
    <div class="d-none d-md-block col-md-7"> 
      <img src="<?=site_url()?>/wp-content/uploads/2018/03/WorldMap-01.png" alt="TESCOM map" class="img-responsive" /> 
    </div> 
    <div class="col-md-5" > 
      <h3>COME VISIT OUR OFFICE</h3>
      <div class="footerAboutCompany">
        <p>Tescom Silicon Valley Center</p>
        <p>1500 Wyatt Dr, Suite 15</p>
        <p>Santa Clara, CA 95054 </p>
        <p>ph 1(408)703-4284</p>
      </div>
    </div>
    <div class="d-md-none col-md-7"> 
      <img src="<?=site_url()?>/wp-content/uploads/2018/03/WorldMap-01.png" alt="TESCOM map" class="img-responsive" /> 
    </div> 
  </div> <!-- end row--> 
  <br/>
  <br/>
  <div class="row">
    <div class="container-fluid">
      <form class="form-horizontal bottomSearch hidden-xs" method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>" role="search">
        <div class="form-group">
          <input type="text" id="s" class="form-control" name="s" placeholder="SEARCH" /> 
        </div>
        <input type="hidden" id="searchsubmit" />
      </form>
      </div> 
  </div> <!-- end row--> 
  <div class="container-fluid">
    <h4>Copyright Tescom Silicon Valley Center <?=date('Y')?></h4>
  </div>
  </div>
</div>
