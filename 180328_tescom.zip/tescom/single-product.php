<?php get_header(); ?>
<?php get_template_part('template-part', 'head'); ?>
<?php get_template_part('template-part', 'topnav'); ?>

<!-- start content container -->

    <?php

$des = get_field("des");
$dim = get_field("dim");
$per = get_field("per");
$options = get_field("customization_options");
$data = get_field("download_data_sheet");
$imgRear = get_field("rear_view_Image");
$imageSide = get_field("side_view_Image");
$category = get_the_category();
$pst = get_field("type_of_shield");
$cust_field = get_post_custom();
$shield_type = strtolower($cust_field['type_of_shield'][0]);
$url = site_url('/')."product-catalog/shield-boxes-manual/";
if($shield_type == 'pneumatic')
    $url = site_url('/')."product-catalog/shield-boxes-pneumatic/";
 elseif($shield_type == 'tem')
  $url = site_url('/')."product-catalog/shield-boxes-tem-cells/";

$cat = ($pst == 'Testers') ? '<a href="'.site_url('/').'product-catalog/testers/">Testers</a>' : '<a href="'.$url.'">Sheild Boxes</a>';

?>


<div class="container myProduct">
  <div class="row margin-bottom-40">
    <div class="col-xs-12 col-offset margin-bottom-15" style="margin-top: 20px;">
      <span class="cbreadcrumb"><a href="<? echo site_url('/');?>">Entire Product Catalog ></a> <?=$cat?> > <? the_title();?></span>
      <h1 class="entry-title" style="margin-top: 0;"><span><strong><? the_title();?></strong> <?=$category[0]->name?></span></h1>
    </div>
 </div>
  <!--close row-->
 

<br />







<div class="row margin-bottom-40">

    <div class="col-md-6">
      <div class="col-xs-12 portfolio-item myBox margin-bottom-40">
        <img src="<?php the_post_thumbnail_url(); ?>" class="img-responsive" />
       <h3>Font View</h3>
      </div>

      <div class="col-xs-12 portfolio-item myBox ">
        <?php    if( !empty($imageSide) ):  ?>
        <img src="<?php echo $imageSide ?>" class="img-responsive" alt="<?php wp_title(); ?>" />
        <h3>Rear View</h3>
         <?php endif; ?>
      </div>
    </div>  
      
    <div class="col-md-6">
          <div class="col-xs-12">
            <?php if($des){ ?>
            <h2>Description:</h2>
            <p><?php echo $des; ?></p>
            <?php } ?>
          </div>
          <div class="col-xs-12">
            <?php if($per){ ?>
            <h2>Key Features:</h2>
            <p><?php echo $per; ?></p>
            <?php } ?>
          </div>

          <div class="col-xs-12">
                   <? if ($data){?>
                 <br clear="both"><br>
                 
                  <p><strong><a href="<? echo $data?>" download>Download Data Sheet</a></strong></p>
                  <?php } ?>  
                
                  <br clear="both"><br>
                 
            <button class="reqquote" onclick="window.location.href='<?echo site_url();?>/customer-support/'" class="request">Request a Quote</button>
          </div>
       
    </div>
</div>
    
    
</div>
<!-- end content container -->

<?php get_footer(); ?>
