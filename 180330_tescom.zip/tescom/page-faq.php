<?php 
/*
 * Template Name: Custom FAQ Page
 * Description: Page template without sidebar
 */
get_header(); ?>
<?php get_template_part('template-part', 'head'); ?>
<?php get_template_part('template-part', 'topnav'); ?>

<!-- start content container -->

<div class="container">
  <div class="row faq">
    <div class="col-md-12" style="margin-top: 20px;">
      <span class="cbreadcrumb"><a href="<? echo site_url('/');?>">Entire Product Catalog ></a> F.A.Q </span>
      <h1 class="entry-title hidden-xs" style="margin-top: 0;"><span><strong>FREQUENTLY</strong> ASKED QUESTIONS</span></h1>
      <h1 class="entry-title hidden-sm hidden-md hidden-lg" style="margin-top: 0;"><span><strong>F.A.Q</strong></span></h1>
    </div>
  </div>
 
 
  <div class="col-md-10 col-xs-12 col-md-offset-1 faqpage">
    <?php // theloop
        if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <?php the_content(); ?>
    <?php endwhile; ?>
    <?php else: ?>
    <?php get_404_template(); ?>
    <?php endif; ?>
  </div>

<!-- end content container -->
</div>
<?php get_footer(); ?>
