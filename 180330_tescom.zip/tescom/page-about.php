<?
/*
 * Template Name: Custom About Us
 * Description: Page template without sidebar
 */
?>
<?php get_header(); ?>
<?php get_template_part('template-part', 'head'); ?>
<?php get_template_part('template-part', 'topnav'); ?>

<div class="container about">
  <div class="row faq">
    <div class="col-md-12" style="margin-top: 20px;">
      <span class="cbreadcrumb"><a href="<? echo site_url('/');?>">Entire Product Catalog ></a> About US </span>
      <h1 class="page-header entry-title" style="margin-top: 0;">
        <span><strong>About</strong> Tescom SVC</span>
      </h1>
    </div>
  </div>
  <div class="row">
    <div class="col-md-10 dmbs-main col-md-offset-2">
      <?php // theloop
        if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
      <?php the_content(); ?>
      <?php endwhile; ?>
      <?php else: ?>
      <?php get_404_template(); ?>
      <?php endif; ?>
    </div>
  </div>
  
  <!-- team-->
   <div class="row">
      <div class="col-md-10 col-md-offset-2"><h2 style="margin-bottom:38px;">Our Team</h2></div>
   </div>
 <div class="row margin-bottom-40">
   
  <?php  
$posts = get_posts(array(
	'posts_per_page'	=> -1,
	'post_type'			=> 'team',
	
));

if( $posts ): 
foreach( $posts as $post ): 
setup_postdata( $post );
  ?>
   
   
    <div class="col-md-10 col-md-offset-2  clearfix portfolioitem ">
          <div class="col-xs-12">
          <?php the_post_thumbnail('full', array('class' => 'img-responsive1 ', 'width' => '180', 'align'=>'absmiddle','style'=>'float:left')); ?>
            <p>
            <? the_title();?>
            <br />
            <? the_field("jobTitle"); ?>
            <br />
            <span class="hidden-xs hidden-xsdden-sm"> <a href="mailto:<? the_field("emailAdd"); ?>" target="_top">
            <? the_field("emailAdd"); ?>
            </a></span> <span class="hidden-xs hidden-sm">
            <br />
            <? $value = get_field( 'brief_bio', $post->ID, false );
            echo $value;
            //the_field("brief_bio");
             ?>
            
            <!--div class="small text-right">
            <?php edit_post_link(); ?>
            </div-->
            </span> 
            </p>
            <br clear="both" /><br />
         </div>
 
   
  </div>
  
  <br /><br />
  
  

<!--ends row-->
<?php endforeach; ?>
<?php wp_reset_postdata(); ?>
<?php endif; ?>

 </div>
 <div class="row margin-bottom-40">
  <br><br><br><br>
  </div>
<!-- end manual shields -->

</div>
<!-- end content container -->

<?php get_footer(); ?>
