<?php 
/*
 * Template Name: Custom FORM
 * Description: Page template without sidebar
 */
get_header(); ?>
<?php get_template_part('template-part', 'head'); ?>
<?php get_template_part('template-part', 'topnav'); ?>
<?php $title = get_the_title();?>

<!-- start content container -->
<div class="container">
  <div class="row">
    <div class="col-md-12" style="margin-top: 20px;">
    <?php

if(strtolower($title) == 'contact us'){
  $title = "<strong>Contact</strong> US";
?>
      <span class="cbreadcrumb"><a href="<? echo site_url('/');?>">Entire Product Catalog ></a> Contact US </span>
      <h1 class="page-header entry-title" style="margin-bottom: 0;margin-top: 0;">
        <span><?php echo $title;?></span>
      </h1>
      <span style="margin-bottom: 60px; display: block;">If this is an urgent matter, please call us at (408)703-4284</span>
<?php }else{ ?>
    <h1 class="page-header entry-title" style="margin-bottom: 60px;">
        <span><?php the_title();?></span>
      </h1>
<?php } ?>
     
    </div>
  </div>
  <div class="col-md-4 col-md-offset-4 col-xs-12 mobcontact">
    <span style="color: #fb7a46; font-weight: bold;">Field with an asterisk(*) are mandatory.</span><br><br>
    <?php // theloop
        if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
    <?php the_content(); ?>
    <?php endwhile; ?>
    <?php else: ?>
    <?php get_404_template(); ?>
    <?php endif; ?>
  </div>

<!-- end content container -->
</div>
<?php get_footer(); ?>
