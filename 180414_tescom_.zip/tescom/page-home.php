<?php
/*
 * Template Name: Custom Home Page
 * Description: Page template without sidebar
 */
?>
<?php get_header(); ?>
<?php get_template_part('template-part', 'head'); ?>
<?php get_template_part('template-part', 'topnav'); 
$mName = get_field("mobile_name");
$des = get_field("des");
$dim = get_field("dim");
$per = get_field("per");
$options = get_field("customization_options");
$data = get_field("download_data_sheet");
$imgRear = get_field("rear_view_Image");
$imageSide = get_field("side_view_Image");
?>
<div id="jsresp"></div>
<!-- start content container -->

<div class="container">
  <div class="row">
    <div class="col-sm-12">
      <h1 class="entry-title"><span><strong>SHIELD</strong> BOXES</span></h1>
    </div>
  </div>
  <!--close row-->
  <div class="row">
  
  
    <div class="col-sm-12">
      <h4 class="subCat">Manual Shield Boxes</h4>
    </div>
  </div>
  <!--close row-->


  
  <div class="row">
  
  <ul class="lightSlider" id="lightSlider1">
    <?php  
$posts = get_posts(array(
	'posts_per_page'	=> -1,
	'post_type'			=> 'product',
	'meta_key'		=> 'type_of_shield',
	'meta_value'	=> 'Manual'
));

if( $posts ): 
 $i=0; 
foreach( $posts as $post ): 
setup_postdata( $post );
$mName = get_field("mobile_name");
$des = get_field("des");
$dim = get_field("dim");
$per = get_field("per");
$options = get_field("customization_options");
$data = get_field("download_data_sheet");
$imgRear = get_field("rear_view_Image");
$cls = ($i<1) ? 'active' : '';
?>

 

  
  
    <li class="col-md-3 col-xs-6 portfolio-item myBox item <?=$cls?>"> <a href="<? the_permalink(); ?>">
      <?php the_post_thumbnail('full', array('class' => 'img-responsive center-block', 'width' => '160')); ?>
      </a>
 
     
     
      <h3 class=" text-nowrap"> <a href="<? the_permalink(); ?>">
        <? the_title();?>
        </a> 
        </h3>
       
         <!--h3 class="col-xs-12 hidden-lg hidden-md hidden-sm text-nowrap "> <a href="<? the_permalink(); ?>">
        <? echo $mName;?>
        </a> 
        </h3-->
        
    </li>
    <?php 
    $i++;
    endforeach; ?>
  </ul>
  </div>
  <!--ends row-->
  
  <?php wp_reset_postdata(); ?>
  <?php endif; ?>
  <!-- end manual shields --> 
  
  <!--======================TEM -->
  
  <div class="row">
    <div class="col-sm-12">
      <h4 class="subCat">Pneumatic Shield Boxes</h4>
    </div>
  </div>
  <!--close row-->
  <div class="row ">
  <ul class="lightSlider" id="lightSlider2">
    <?php  
$posts = get_posts(array(
	'posts_per_page'	=> -1,
	'post_type'			=> 'product',
	'meta_key'		=> 'type_of_shield',
	'meta_value'	=> 'Pneumatic'
));

if( $posts ): 
  $i=0; 
foreach( $posts as $post ): 
setup_postdata( $post );
  ?>
    <li class="col-md-3 col-xs-6 portfolio-item"> <a href="<? the_permalink(); ?>">
      <?php the_post_thumbnail('full', array('class' => 'img-responsive center-block', 'width' => '160')); ?>
      </a>
        <h3 class="text-nowrap"> <a href="<? the_permalink(); ?>">
        <? the_title();?>
        </a> 
        </h3>
       
         <!--h3 class="col-xs-12 hidden-lg hidden-md hidden-sm text-nowrap "> <a href="<? the_permalink(); ?>">
        <? echo $mName;?>
        </a> 
        </h3-->
    </li>
    <?php 
    endforeach; ?>
 <!-- Left and right controls -->
  </ul>
  </div>

  <!--ends row-->
  
  <?php wp_reset_postdata(); ?>
  <?php endif; ?>
  <!--======================TEMENDS --> 
  
  <!--======================TEM -->
  
  <div class="row">
    <div class="col-sm-12">
      <h4 class="subCat">TEM Cells</h4>
    </div>
  </div>
  <!--close row-->
  <div class="row">
  <ul class="lightSlider" id="lightSlider3">
    <?php  
$posts = get_posts(array(
	'posts_per_page'	=> -1,
	'post_type'			=> 'product',
	'meta_key'		=> 'type_of_shield',
	'meta_value'	=> 'TEM'
));

if( $posts ): 
foreach( $posts as $post ): 
setup_postdata( $post );
  ?>
    <li class="col-md-3  col-xs-6 portfolio-item"> <a href="<? the_permalink(); ?>">
      <?php the_post_thumbnail('full', array('class' => 'img-responsive center-block', 'width' => '160')); ?>
      </a>
         <h3 class="hidden-xs text-nowrap"> <a href="<? the_permalink(); ?>">
        <? the_title();?>
        </a> 
        </h3>
       
         <h3 class="col-xs-12 hidden-lg hidden-md hidden-sm text-nowrap "> <a href="<? the_permalink(); ?>">
        <? echo $mName;?>
        </a> 
        </h3>
    </li>
    <?php endforeach; ?>
   </ul> 
  </div>
  <!--ends row-->
  
  <?php wp_reset_postdata(); ?>
  <?php endif; ?>
  <!--======================TEMENDS --> 
  
  
   
  <!--======================TESTERS-->
  

  <div class="row" style="margin-top: 30px;">
    <div class="col-sm-12">
       <h1 class="entry-title"><span><strong>Testers</strong></span></h1>
    </div>
  </div>
  <!--close row-->
  

  <div class="row"style="margin-bottom:150px;">
  <ul class="lightSlider" id="lightSlider4">
    <?php  
$posts = get_posts(array(
	'posts_per_page'	=> -1,
	'post_type'			=> 'product',
	'meta_key'		=> 'type_of_shield',
	'meta_value'	=> 'testers'
));

if( $posts ): 
foreach( $posts as $post ): 
setup_postdata( $post );
  ?>
    <li class="col-md-3 col-xs-6 portfolio-item" > <a href="<? the_permalink(); ?>">
      <?php the_post_thumbnail('full', array('class' => 'img-responsive center-block', 'width' => '160')); ?>
      </a>
 
     
     
      <h3 class="hidden-xs text-nowrap"> <a href="<? the_permalink(); ?>">
        <? the_title();?>
        </a> 
        </h3>
       
         <h3 class="col-xs-12 hidden-lg hidden-md hidden-sm text-nowrap "> <a href="<? the_permalink(); ?>">
        <? echo $mName;?>
        </a> 
        </h3>
        
    </li>
    <?php endforeach; ?>
    </ul>
  </div>
  <!--ends row-->
  
  <?php wp_reset_postdata(); ?>
  <?php endif; ?>
  <!--======================TEMENDS --> 
  
  
  
  
  
</div>
<?php get_footer(); ?>
