<?php /* Template Name: Page - Dashboard Template */ ?>

<?php get_header(); ?>

<?php get_template_part('template-part', 'head'); ?>

<?php get_template_part('template-part', 'topnav'); ?>

<?php // theloop
        if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

<!-- If the user is logged in, view the dashboard -->
<?php if (is_user_logged_in() ) { ;?>

  <!-- nav class="navbar fixed-top navbar-expand-lg justify-content-center">
    <a class="navbar-brand d-flex mr-auto"> 
      <h1 class="username">
        Hello,
        <?php
            $current_user = wp_get_current_user();
            echo $current_user->user_login;
        ?>!
      </h1>
    </a> 
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapseContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse text-center" id="navbarCollapseContent">
      <ul class="nav navbar-nav ml-auto w-100 justify-content-end">
        <li class="nav-item">
          <a class="dashboardHeader" href="<?=site_url()?>/dashboard">Dashboard</a>
         </li>
        <li class="nav-item">
          <a class="dashboardHeader" href="<?=site_url()?>/settings">Settings</a>
         </li>
         <li class="nav-item">
          <a class="dashboardHeader" href="<?=site_url()?>/contact-us">Contact Us</a>
         </li>
        <li class="nav-item">
         <a class="dashboardHeader" href="<?=site_url()?>/wp-login.php?action=logout&redirect_to=<?=site_url()?>">
         Logout</a>
         </li>
        <li class="nav-item">
         </li>
      </ul>
    </div>
  </nav -->
  
        <div class="container contentContainer">
            <h1 class="username">
            Welcome back,
            <?php
            $current_user = wp_get_current_user();
            echo $current_user->user_login;
            ?>!
            </h1>
            
            <div class="dashboard-wrapper">
            
            <div class="dashboard-nav">
            <li class="nav-item">
            <a class="dashboardHeader" href="<?=site_url()?>/dashboard">Dashboard</a>
            </li>
            <li class="nav-item">
            <a class="dashboardHeader" href="<?=site_url()?>/settings">Settings</a>
            </li>
            <li class="nav-item">
            <a class="dashboardHeader" href="<?=site_url()?>/wp-login.php?action=logout&redirect_to=<?=site_url()?>">
             Logout</a>
            </li>
            </div>
            
            <div class="dashboard-content">
            <?php the_content(); ?>
            </div>
            
            </div>
            
        </div>

<!-- If the user is not logged in, direct users to log in -->
<?php } elseif (!is_user_logged_in() ) { ;?>
  <div class="container contentContainer">
    <h3 style="page-header">You must be logged in to view this page. <a href="<?=site_url()?>/login">Login here.</a></h3>
  </div>
<?php };?>

        <?php endwhile; ?>
        <?php else: ?>

            <?php get_404_template(); ?>

        <?php endif; ?>
</div>
<?php get_footer(); ?>
