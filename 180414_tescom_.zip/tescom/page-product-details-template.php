<?php /* Template Name: Page - Product Details Template */ ?>

<?php get_header(); ?>

<?php get_template_part('template-part', 'head'); ?>

<?php get_template_part('template-part', 'topnav'); ?>

<div class="container contentContainer productDetailsContainer">
  <?php // theloop
  if ( have_posts() ) : while ( have_posts() ) : the_post();
    the_content(); 
    $title = get_the_title();
    $query = new AirpressQuery();
    $query->setConfig("Product Catalog");
    $query->table("Product Catalog");
    $query->addFilter("{Name}='$title'");
    $events = new AirpressCollection($query);
  foreach($events as $e): 
 
    $type = $e["Type"];?> 
<!-- Hidden on XS screens -->
<div class="d-none d-sm-block">
    <div class="row productDetailsRow">
      <h1 class="page-header"> 
        <a href="/<?php echo $type ;?>"><?php echo $type ;?></a> < <a class="productNameLink" href="/<?php echo $title ;?>"><?php echo $title ;?></a>
      </h1>
    </div>
</div>
<!-- Visible only on XS screens -->
<div class="d-block d-sm-none">
    <div class="row productDetailsRow">
      <h1 class="page-header"> 
        <a href="/<?php echo $type ;?>"><?php echo $type ;?>
        </a>
        < 
        <a class="productNameLink" href="/<?php echo $title ;?>"><?php echo $title ;?></a>
      </h1>
    </div>
</div>
    <div class="col-md-4">
      <div class="card">
          <?php $productImageUrl = $e["Product Image"][1]["url"] ;?>
          <?php if ($productImageUrl) { ;?>
            <img class="img-responsive card-img-top" src="<?php echo $productImageUrl ;?>" alt="Product Image"/>
          <? } ;?>
      </div>
    </div>
    <div class="col-md-8">
      <div class="row productDetailsHeader">
        <h3   style="text-align: left;">Features Unique to <?php echo $title ;?> </h3>
      </div>
      <div class="row productDetailsRow">
        <?php $uniqueFeature = $e["Unique Feature"] ;?>
        <p style="text-align: left;"> <?php echo $uniqueFeature ;?> </p>
      </div><!-- row productDetailsRow -->
      
      
      <div class="row productDetailsRow">
        <div class="row container productShielding">
          <h3 style="text-align: left;">Standard Features</h3>
        </div>
        <div class="card-deck" id="product-page">
          <div class="card">
          <img class="size-thumbnail card-img-top wp-image-639 alignnone img-graphic" src="http://staging.tescomsvc.com/wp-content/uploads/2018/03/Graphic-Features-300x204.png" alt="" width="300" height="204" />
            <div class="card-body">
            <h3>Easy to customize</h3>
            </div>
          </div>
          
          <div class="card">

          <img class="size-thumbnail card-img-topwp-image-641 alignnone img-graphic" src="http://staging.tescomsvc.com/wp-content/uploads/2018/03/Graphic-Shock-300x204.png" />
            <div class="card-body">
            <h3>Easy to customize</h3>

            </div>
          </div>
          <div class="card">

          <img class="size-thumbnail card-img-top wp-image-640 alignnone img-graphic" src="http://staging.tescomsvc.com/wp-content/uploads/2018/03/Graphic-RF-300x204.png" />
            <div class="card-body">
            <h3>High RF Shielding</h3>
            </div>
          </div>
        </div><!-- card deck -->
      </div><!-- row productDetailsRow -->
      <div class="row productShielding">
        <div class="row container productShielding">
          <h3 style="text-align: left;">Ideal Application</h3>
        </div>
      </div>
      <div class="row productDetailsHeader">
        <div class="col-md-3" style="text-align:left;">
          <div class="row productShielding">
           <p><?php echo $e["Application"][0];?></p>
          </div>
          <div class="row productShielding">
            <p><?php echo $e["Application"][1] ;?></p>
          </div>
        </div>
        <div class="col-md-3" style="text-align:left;">
          <div class="row productShielding">
            <p><?php echo $e["Application"][2] ;?></p>
          </div>
          <div class="row productShielding">
            <p><?php echo $e["Application"][3] ;?></p>
          </div>
        </div>
      </div> 
      <div class="row productDetailsHeader">
        <h3   style="text-align: left;">Typical RF Shielding</h3>
      </div>
      <div class="row productDetailsRow">
        <p style="text-align: left;"><?php echo $e["Shielding Effectiveness"] ;?></p>
      </div><!-- row productDetailsRow -->
      <div class="row productShielding">
        <h3   style="text-align: left;">Specifications</h3>
      </div>
      <div class="row productShielding">
        <?php $inner = $e["Inner Dimension (WxDxH)"] ;?>
      </div>
      <div class="row productShielding">
        <p>Inner Dimension: <?php echo $inner ;?></p><br/>
        <?php $outer = $e["Outer Dimension (WxDxH)"] ;?>
      </div>
      <div class="row productShielding">
        <p>Outer Dimension:<?php echo $outer ;?></p><br/>
      </div>
      <div class="row productShielding">
        <p>Weight: <?php echo $e["Weight"] ;?></p><br/>
      </div>
      <div class="row productShielding">
        <p>Weight (Packed): <?php echo $e["Weight (Packed)"] ;?></p>
      </div><!-- row productDetailsRow -->
      <div class="row productDetailsHeader">
        <h3   style="text-align: left;">Customization Options</h3>
      </div>
      <div class="row productDetailsRow">
        <?php $datasheet = $e["Datasheet"] ?> 
        <?php foreach($datasheet as $d): ?>
          <p style="text-align: left;">Please download and review the <a class="datasheetLink" href="<?php echo $d["url"] ;?>" download="<?php echo $d["filename"] ;?>">datasheet.</a></p>
      </div><!-- row productDetailsRow -->
    <div class="col-md-9">
      <div class="row">
      
        <div class="card-deck" id="graphic-buttons">
          <div class="card">
            <a href="<?php echo $d["url"] ;?>" download="<?php echo $d["filename"] ;?>">
            <img src="http://staging.tescomsvc.com/wp-content/uploads/2018/03/Graphic-Datasheet_v2-300x300.png" alt="" width="150" class="size-thumbnail wp-image-694 card-img-top img-buttons" />
            </a>
            <div class="card-body">
            <a class="productQ" href="<?php echo $d["url"] ;?>" download="<?php echo $d["filename"] ;?>">
            <h3 class="productQ">Download Datasheet</h3></a>
            </div>
        <?php endforeach ;?>
          </div>
          <div class="card">
            <a href="/contact-us">
            <img src="http://staging.tescomsvc.com/wp-content/uploads/2018/03/Graphic-Quote_v2-300x300.png" alt="" width="150" height="150" class="size-thumbnail wp-image-698 card-img-top img-buttons" />
            </a>
            <div class="card-body">
            <a class="productQ" href="/contact-us">
            <h3 class="productQ">Request Quote</h3></a>
            </div>
          </div>
          <div class="card">
            <a href="/contact-us">
            <img src="http://staging.tescomsvc.com/wp-content/uploads/2018/03/Graphic-Question_v2-300x300.png" alt="" width="150" height="150" class="size-thumbnail wp-image-696 card-img-top img-buttons" />
            </a>
            <div class="card-body">
            <a class="productQ" href="/contact-us">
            <h3 class="productQ">Ask Question</h3></a>
            </div>
          </div>
        </div><!-- card deck -->
      </div><!-- row productDetailsRow -->
    </div>
  </div><!--col-md-->
</div> <!-- contentContainer-->
<br/><br/><br/><br/>
<div class="productTableContainer">
  <div class="row">
    <div class="container">
      <?php if ($type == 'Shield Boxes') { 
          get_template_part( 'tables/shield-boxes', 'page');
        } else if ($type == 'TEM Cells') { 
          get_template_part( 'tables/tem-cells', 'page');
        } else if ($type == 'Test Instruments') { 
          get_template_part( 'tables/test-instruments', 'page');
        }  
        endforeach 
      ;?>

      <?php endwhile; ?>
      <?php else: ?>
        <?php get_404_template(); ?>
      <?php endif; ?>
    </div> 
  </div> <!--row productDetailsRow-->
</div> <!-- contentContainer-->
<?php get_footer(); ?>
